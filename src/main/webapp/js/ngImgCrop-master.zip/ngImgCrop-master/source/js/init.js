'use strict';

var crop = angular.module('ngImgCrop', []);